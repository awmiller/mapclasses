/* 
 * Andrew Miller
 * 915113828
 * amiller2@sfsu.edu
 * gcc version 4.9.3 (GCC)
 */

#include "node.h"

Node::Node(int value) {
  this->value = value;
}
